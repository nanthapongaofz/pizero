def helloworld_1():
	return 'hello world!'


if __name__ == "__main__":
	a = helloword_1()
